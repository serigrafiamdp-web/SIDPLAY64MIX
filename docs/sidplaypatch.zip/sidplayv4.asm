;
; Soci/Singular wuz hir ;)
;
; look for "***" where some patches are needed for IDE64.
;
		*= $1100

z2              = $2
z3              = $3
z4              = $4
p5              = $5
p7              = $7
p9              = $9
zb              = $b
zc              = $c
zd              = $d
ze              = $e
zf              = $f
z10             = $10
z12             = $12
z13             = $13
z16             = $16
z17             = $17
z18             = $18
z19             = $19
z1b             = $1b
z1d             = $1d
z1e             = $1e
t22             = $22
z42             = $42
z62             = $62
z83             = $83
z84             = $84
z85             = $85
z88             = $88
z89             = $89
z90             = $90
zcc             = $cc
zf2             = $f2
zf3             = $f3
zf4             = $f4
zf5             = $f5
zf6             = $f6
pfc             = $fc
zfe             = $fe
tff             = $ff
t100            = $100
t10a            = $10a
t114            = $114
m124            = $124
m125            = $125
m126            = $126
m127            = $127
t128            = $128
l12d            = $12d
t12f            = $12f
l130            = $130
l133            = $133
l136            = $136
l139            = $139
l13c            = $13c
l13f            = $13f
t153            = $153
l15c            = $15c
m15d            = $15d
m15e            = $15e
l15f            = $15f
m160            = $160
m161            = $161
m162            = $162
p163            = $163
p165            = $165
p167            = $167
p169            = $169
p16b            = $16b
t16d            = $16d
m172            = $172
m173            = $173
m174            = $174
m175            = $175
m176            = $176
m177            = $177
m178            = $178
m179            = $179
t17a            = $17a
m17e            = $17e
t17f            = $17f
m28a            = $28a
m28c            = $28c
m291            = $291
m2a6            = $2a6
tde50           = $de50
tdf50           = $df50
te000           = $e000

stack_code
		.fill 40,$00
		.byte "03:05"
		jmp lc9ea
					;1130
		jmp lcae7
					;1133
		jmp lcee5
					;1136
		jmp lcee5
					;1139
		jmp lc98b
					;113c
		jmp lc8bb
					;113f
		jmp lc95b
					;1142
		jmp lcdbe
					;1145
		jmp lcdc3
					;1148
		sei
		ldx #$ff		;255
		txs
		inx
		stx $d020
		jmp (p163)
					;1153
t_153
		.byte $05,$06,$0a,$0a,$05,$04,$05,$09
		.byte $09
l_15c
		.byte $4c
m_15d
		.byte $5c
m_15e
		.byte $01
l_15f
		.byte $4c
m_160
		.byte $5f
m_161
		.byte $01
m_162
		.byte $00
p_163
		.word xc807
p_165
		.word xc97a
p_167
		.word xcbd8
p_169
		.word lce89
p_16b
		.word lce73
t_16d
		.byte $04,$05,$07,$0a,$0a
m_172
		.byte $c4
m_173
		.byte $e0
m_174
		.byte $00
m_175
		.byte $02
m_176
		.byte $4d
m_177
		.byte $00
m_178
		.byte $00
m_179
		.byte $00
t_17a
		.byte $00,$00,$00,$00
m_17e
		.byte $01
t_17f
		.byte "NO FILES PRESENT   "
		.fill 44654,$00
start
		sei
		cld
		lda #$36		;"6"
		sta $01
		ldy #$92		;146
lc008
		lda stack_code-1,y
		sta tff,y
		dey
		bne lc008
		ldx #$ff		;255
		txs
		lda #$80		;128
		sta m28a
		sta m291
		sta $d020
		sta $d021
		lda #0
		jsr $ff90               ;message
		ldx #0
		lda #5
lc02b
		sta $d800,x
		sta $d900,x
		sta $da00,x
		sta $db00,x
		inx
		bne lc02b
		ldx #$25		;"%"
lc03c
		lda #$0f		;15
		sta ldb98+1,x
		dex
		bpl lc03c
		ldx #$1e		;30
		lda #1
lc048
		sta $d880,x
		sta $d8a8,x
		sta $d8d0,x
		dex
		bpl lc048
		ldx #3
lc056
		sta $d920,x
		sta $d948,x
		sta $d970,x
		sta $d998,x
		dex
		bpl lc056
		ldx #7
lc067
		sta $db2b,x
		sta $d8f8,x
		dex
		bpl lc067
		ldx #4
lc072
		sta $db56,x
		dex
		bpl lc072
		lda #$d9		;217
		sta p5+1
		lda #$2c		;","
		sta p5
		ldx #$0e		;14
lc082
		ldy #$12		;18
lc084
		cpy #$10		;16
		bge lc08b
		lda #$0d		;13
		.byte $2c		;bit
lc08b
		lda #$0f		;15
		sta (p5),y
		dey
		bpl lc084
		lda p5
		clc
		adc #$28		;40
		bcc *+4
		inc p5+1
		sta p5
		dex
		bpl lc082
		ldx #$0f		;15
		lda #$0d		;13
lc0a4
		sta $d82e,x
		dex
		bpl lc0a4
		sta $d9a1
		sta $d9a2
		lda $ba
		sta m174
		sta zf4
		sed
		lda #0
		sta pfc
		ldx #8
lc0be
		asl zf4
		lda pfc
		adc pfc
		sta pfc
		dex
		bne lc0be
		cld
		lda pfc
		tax
		lsr
		lsr
		lsr
		lsr
		ora #%00110000
		sta mc5a1
		txa
		and #%00001111
		ora #%00110000
		sta mc5a2
		lda #$33		;"3"
		sta $01
		ldy #8
		ldx #0
lc0e6                                   ;accessed parameter
		lda $d800,x
mc0eb           = *+2			;accessed parameter
		sta te000,x
		inx
		bne lc0e6
		inc lc0e6+2
		inc mc0eb
		dey
		bne lc0e6
		lda #$38		;"8"
		sta $01
		ldx #$31		;"1"
lc0fe
		lda $300,x
		sta tdf50,x
		dex
		bpl lc0fe
		lda #$36		;"6"
		sta $01
		lda #0
		sta z2
		sta z3
		sta z4
		lda #$c4		;196
		sta m172
		lda #$e0		;224
		sta m173
		lda #0
		sta $dd00
		lda #$18		;24
		sta $d018
		ldx #$d1		;209
		lda m2a6
		bne *+4
		ldx #$51		;"Q"
		stx mcbd2
		jmp lc830
					;c136
		.fill 714,$00
		.byte $70
		.fill 21,$40
		.byte $72
		.fill 16,$40
		.byte $6e,"]RSID:"
		.fill 16,$20
		.byte "]MEM: $0000-$0000]",$6b
		.fill 21,$40
		.byte $71
		.fill 16,$40
		.byte $73,"]TITLE :"
		.fill 31,$20
		.byte "]]AUTHOR:"
		.fill 31,$20
		.byte "]](C)   :"
		.fill 31,$20
		.byte "]]SONG  :           ",$70
		.fill 19,$40
		.byte $73,"]CHIP  :           ]"
		.fill 19,$20
		.byte "]]SYSTEM:           ]"
		.fill 19,$20
		.byte "]]INIT  $        ",$70,$40,$40,$73
		.fill 19,$20
		.byte "]]PLAY  $        ]"
mc5a1
		.byte " "
mc5a2
		.byte " :"
		.fill 19,$20
		.byte $5d,$6b,"@@@@@@@@@@@@@@@",$71,$40,$40,$73
		.fill 19,$20
		.byte "]]R/N   :RANDOM/NEXT]"
		.fill 19,$20
		.byte "]]M     :MANUAL     ]"
		.fill 19,$20
		.byte "]]</>   :SET SHUFFLE]"
		.fill 19,$20
		.byte "]]+/-   :SELECT SONG]"
		.fill 19,$20
		.byte "]]F1/F7 :PLAY/STOP  ]"
		.fill 19,$20
		.byte "]]RETURN:LOAD SID   ]"
		.fill 19,$20
		.byte "]]SPACE :DIRECTORY  ]"
		.fill 19,$20
		.byte $5d,$6b
		.fill 18,$40
		.byte $73
		.fill 19,$20
		.byte "]]CLOCK:    00:00:00]"
		.fill 19,$20
		.byte "]]SHUFFLE:     03:05]"
		.fill 19,$20
		.byte $5d,$6b
		.fill 18,$40
		.byte $71
		.fill 19,$40
		.byte $73,"]     SIDPLAY64 V0.4 ",$02,$19
		.byte " GRG/SHAPE      ]",$6d
		.fill 38,$40
		.byte $7d
timing_consts
		.byte $fe,$00,$bf,$00,$7f,$fe,$fe,$df
		.byte $df,$fb,$ef,$fe,$df,$df,$ef,$7f
		.byte $6f,$f7,$e7,$ef,$fd,$f7,$7f,$ef
		.byte $fd,$7f,$ef,$fe,$f7,$ef,$2c
xc807
		ldy #0
		jsr l136
		lda $d011
		ora #%00010000
		sta $d011
		cpy #0
		beq *+5
		jmp (p165)
					;c81b
		lda #$99		;153
		sta p9
		lda m172
		clc
		adc #3
		sta p9+1
		ldy #$25		;"%"
		lda #$20		;" "
lc82b
		sta (p9),y
		dey
		bpl lc82b
lc830
		lda #0
		sta z2
		sta z3
		sta z4
		sta pfc
		lda #$d0		;208
		sta pfc+1
		lda #1
		ldx m174
		ldy #$60		;96
		jsr $ffba               ;setlfs
		ldx #8
		ldy #$e8		;232
		jsr $ffbd               ;setnam
		jsr $ffc0               ;open
;		lda $ba     ;*************
;		jsr $ffb4               ;talk
;		lda $b9
;		jsr $ff96               ;tksa
                ldx #1                  ;*******
                jsr $ffc6               ;*******
                .fill 5,$ea             ;*******

		ldy #3
lc85e
		jsr l13f
		tax
		jsr l13f
		dey
		bne lc85e
		cmp #0
		bne lc8b0
		txa
		beq lc8b0
lc86f
		jsr l13f
		cmp #$22		;"""
		bne lc86f
		ldy #0
lc878
		jsr l13f
		sei
		ldx #$38		;"8"
		stx $01
		cmp #$22		;"""
		bne lc88c
		ldx z4
		tya
		sta tde50,x
		lda #$20		;" "
lc88c
		sta (pfc),y
		ldx #$36		;"6"
		stx $01
		cli
		iny
		cpy #$11		;17
		bne lc878
		inc z4
		lda pfc
		clc
		adc #$10		;16
		sta pfc
		bcc *+4
		inc pfc+1
		lda #4
		sta m124
		jsr l13c
		jsr l139
lc8b0
		jsr l13f
		cmp #0
		bne lc8b0
		ldy #2
		bne lc85e
lc8bb
		lda #0
		sta m127
		lda #$2c		;","
		sta p5
		lda m172
		clc
		adc #1
		sta p5+1
		lda $01
		sta zb
		lda z4
		bne lc8e0
		ldy #$12		;18
lc8d6
		lda t17f,y
		sta (p5),y
		dey
		bpl lc8d6
		bmi lc936
lc8e0
		lda m127
		clc
		adc z3
		tax
		pha
		asl
		asl
		asl
		asl
		sta p7
		pla
		lsr
		lsr
		lsr
		lsr
		ora #%11010000
		sta p7+1
		inx
		txa
		ldy $01
		ldx #$38		;"8"
		sei
		stx $01
		jsr ldd6d
		sty $01
		cli
		ldy #$12		;18
		sta (p5),y
		dey
		txa
		sta (p5),y
		dey
		lda #$3a		;":"
		sta (p5),y
		ldx #0
		lda m127
		cmp z2
		bne *+4
		ldx #$80		;128
		stx m126
		dey
lc922
		sei
		ldx #$38		;"8"
		stx $01
		lda (p7),y
		ldx zb
		stx $01
		cli
		eor m126
		sta (p5),y
		dey
		bpl lc922
lc936
		lda p5
		clc
		adc #$28		;40
		bcc *+4
		inc p5+1
		sta p5
		inc m127
		lda m127
		cmp #$0f		;15
		bge lc95a_rts
		cmp z4
		blt lc8e0
		ldy #$12		;18
		lda #$20		;" "
lc953
		sta (p5),y
		dey
		bpl lc953
		bmi lc936
lc95a_rts
		rts
					;c95b
lc95b
		lda z4
		cmp #$b7		;183
		beq lc96e
		lda #0
		sta z90
		jsr $ffcf		;**********$ffa5               ;acptr
		inc z90
		dec z90
		beq lc999_rts
lc96e
		pla			;stack parameters?
		pla			;stack parameters?
		lda #1
		jsr $ffc3               ;close
		lda #5
		sta m124
xc97a
		jsr l13c
		jsr l139
		lda $d011
		ora #%00010000
		sta $d011
		jmp (p165)
					;c98b
lc98b
		lda m28c
		bne lc995
		lda #$10		;16
		sta m28c
lc995
		cmp #$10		;16
		beq *+3
lc999_rts
		rts
					;c99a
		ldx #$ff		;255
		stx $dc01+1
		inx
		stx $dc01+2
		lda #$e8		;232
		sta p5
		lda #$f7		;247
		sta p7
		lda m172
		clc
		adc #3
		sta p5+1
		sta p7+1
		ldy m124
lc9b8
		lda (p5),y
		sta $dc00
		lda (p7),y
		cmp $dc01
		beq lc9c8
		dey
		bpl lc9b8
		rts
					;c9c8
lc9c8
		ldx #5
		stx m125
		inx
		stx m28c
		cpy #1
		bne lc9e6
		lda z3
		clc
		adc z2
		beq lc9fe_rts
		lda z2
		beq lc9e3
		dec z2
		rts
					;c9e3
lc9e3
		dec z3
		rts
					;c9e6
lc9e6
		cpy #0
		bne lc9ff
lc9ea
		lda z3
		sec
		adc z2
		cmp z4
		beq lc9fe_rts
		lda z2
		cmp #$0e		;14
		beq lc9fc
		inc z2
		rts
					;c9fc
lc9fc
		inc z3
lc9fe_rts
		rts
					;c9ff
lc9ff
		cpy #5
		bne lca0f
		lda z4
		beq lca13
		pla			;stack parameters?
		pla			;stack parameters?
		jsr l133
		jmp (p167)
					;ca0f
lca0f
		cpy #4
		bne lca1e
lca13
		pla			;stack parameters?
		pla			;stack parameters?
		jsr l133
		jsr $ffe7               ;clall
		jmp (p163)
					;ca1e
lca1e
		cpy #6
		bne lca31
		lda #0
		sta $d404
		sta $d40b
		sta $d412
		sta m162
		rts
					;ca31
lca31
		cpy #2
		bne lca40
		lda #0
		ldx z2
		bne *+4
		sta z3
		sta z2
		rts
					;ca40
lca40
		cpy #3
		bne lca62
		lda z4
		sec
		sbc #1
		cmp #$0e		;14
		blt lca53
		lda #$0e		;14
		cmp z2
		beq lca56
lca53
		sta z2
		rts
					;ca56
lca56
		lda z4
		sec
		sbc #$0f		;15
		bge *+4
		lda #0
		sta z3
		rts
					;ca62
lca62
		ldx #3
		cpy #7
		bne lca7f
lca68
		cpx #2
		beq lca7b
		dec t128,x
		lda t128,x
		cmp #$2f		;"/"
		bne lca7e_rts
		lda #$35		;"5"
		sta t128,x
lca7b
		dex
		bpl lca68
lca7e_rts
		rts
					;ca7f
lca7f
		cpy #8
		bne lca9a
lca83
		cpx #2
		beq lca96
		inc t128,x
		lda t128,x
		cmp #$36		;"6"
		bne lca99_rts
		lda #$30		;"0"
		sta t128,x
lca96
		dex
		bpl lca83
lca99_rts
		rts
					;ca9a
lca9a
		lda #2
		ldx #$4d		;"M"
		cpy #$0e		;14
		beq lcab2
		lda #0
		ldx #$4e		;"N"
		cpy #$0a		;10
		beq lcab2
		cpy #9
		bne lcab9
		lda #$80		;128
		ldx #$52		;"R"
lcab2
		sta m175
		stx m176
lcab8_rts
		rts
					;cab9
lcab9
		cpy #$0b		;11
		bne *+4
		beq lcade
		cpy #$0d		;13
		bne lcacf
		lda m178
		beq lcab8_rts
		dec m178
		bne lcade
		beq lcade
lcacf
		cpy #$0c		;12
		bne lcab8_rts
		lda m178
		cmp m179
		beq lcab8_rts
		inc m178
lcade
		ldx #$28		;"("
		stx m125
		inx
		stx m28c
lcae7
		php
		sei
		lda #$38		;"8"
		sta $01
		jsr ldd83
		lda #$35		;"5"
		sta $01
		lda #$10		;16
		sta $dc0e
		lda p9
		beq lcb14
		ldx #$25		;"%"
		ldy #$40		;"@"
		lda m17e
		beq lcb0e
		cmp #2
		bne lcb0e
		ldx #$95		;149
		ldy #$42		;"B"
lcb0e
		stx $dc04
		sty $dc05
lcb14
		lda #$0f		;15
		sta $d418
		ldx #$17		;23
		lda #0
lcb1d
		sta $d400,x
		dex
		bpl lcb1d
		ldx #4
lcb25
		sta $dc08,x
		dex
		bpl lcb25
		sta m162
		ldx #$0a		;10
lcb30
		sta $00,x
		inx
		bne lcb30
		ldx #9
lcb37
		lda z2,x
		sta t10a,x
		lda t100,x
		sta z2,x
		dex
		bpl lcb37
		lda m160
		ora m161
		bne lcb8e
		lda #$0b		;11
		sta $d020
		lda #$37		;"7"
		sta $01
		lda $d011
		ora #%00010000
		sta $d011
		lda m178
		tax
		tay
		jsr l15c
		ldx #0
		stx $dc00
lcb6a
		lda $dc01
		cmp $dc01
		beq lcb6a
		sei
		stx $d020
		ldx #$ff		;255
		txs
		ldx #9
lcb7b
		lda z2,x
		sta t100,x
		lda t10a,x
		sta z2,x
		dex
		bpl lcb7b
		jsr l136
		jmp (p165)
					;cb8e
lcb8e
		lda m178
		tax
		tay
		jsr l15c
		sei
		lda #$35		;"5"
		sta $01
		ldx #9
lcb9d
		lda z2,x
		sta t100,x
		lda t10a,x
		sta z2,x
		dex
		bpl lcb9d
		stx m162
		lda p9
		bne lcbc5
		ldy #$4c		;"L"
		ldx #$c7		;199
		lda m17e
		cmp #2
		bne lcbbf
		ldy #$42		;"B"
		dex
lcbbf
		stx $dc04
		sty $dc05
lcbc5
		lda #$32		;"2"
		cmp $d012
		bne lcbc5
		bit $d011
		bmi lcbc5
mcbd2           = *+1			;accessed parameter
		lda #$51		;"Q"
		sta $dc0e
		plp
		rts
					;cbd8
xcbd8
		lda $d011
		and #%11101111
		sta $d011
		lda #$2e		;"."
		sta p9
		lda m172
		sta p9+1
		lda z2
		clc
		adc z3
		tax
		pha
		asl
		asl
		asl
		asl
		sta p7
		pla
		lsr
		lsr
		lsr
		lsr
		ora #%11010000
		sta p7+1
		php
		sei
		lda #$38		;"8"
		sta $01
		ldy #$0f		;15
lcc07
		lda (p7),y
		sta t114,y
		sta (p9),y
		dey
		bpl lcc07
		lda tde50,x
		ldx #$36		;"6"
		stx $01
		plp
		ldx #$14		;20
		ldy #1
		jsr $ffbd               ;setnam
		lda #2
		ldx m174
		tay
		jsr $ffba               ;setlfs
		jsr $ffc0               ;open
		ldx #2
		jsr $ffc6               ;chkin
		ldx #0
lcc33
		jsr $ffcf		;******$ffa5               ;acptr
		cpx #$76		;118
		bge lcc4b
		cpx #$16		;22
		blt lcc4b
		cmp #0
		beq lcc49
		cmp #$60		;96
		blt *+4
		and #%00011111
		.byte $2c		;bit
lcc49
		lda #$20		;" "
lcc4b
		sta zc,x
		inx
		cpx #$7e		;126
		bne lcc33
		jsr $ffcc               ;clrchn
		lda #2
		jsr $ffc3               ;close
		lda zd
		cmp #$53		;"S"
		beq lcc70
		ldx m175
		beq lcc6d
		bmi lcc6d
		stx $d020
		jmp (p163)
					;cc6d
lcc6d
		jmp (p169)
					;cc70
lcc70
		sei
		lda #$38		;"8"
		sta $01
		jmp ldb70
					;cc78
		lda #$36		;"6"
		sta $01
		lda m172
		tax
		and #%11000000
		lsr
		lsr
		lsr
		lsr
		lsr
		lsr
		eor #%00000011
		sta $dd00
		tay
		txa
		and #%00111111
		asl
		asl
		sta zf4
		lda #6
		cpy #3
		beq lccd2
		cpy #1
		beq lccd2
		lda m173
		and #%00111111
		lsr
		lsr
		pha
		php
		sei
		lda #$33		;"3"
		sta $01
		lda #$d8		;216
		sta p7+1
		lda m173
		sta p5+1
		ldx #8
		ldy #0
		sty p7
		sty p5
lccbe
		lda (p7),y
		sta (p5),y
		iny
		bne lccbe
		inc p7+1
		inc p5+1
		dex
		bne lccbe
		lda #$36		;"6"
		sta $01
		plp
		pla
lccd2
		ora zf4
		sta $d018
		ldx #8
		ldy #4
lccdb
		lda m172
		clc
		adc t16d,y
		sta p163+1,x
		dey
		dex
		dex
		bpl lccdb
		ldx #$18		;24
		ldy #8
lccee
		lda m172
		clc
		adc t153,y
		sta t12f,x
		dey
		dex
		dex
		dex
		bpl lccee
		;lda #8
		;ldx $ba
		;ldy #0
;		jsr $ffba               ;setlfs
		lda #0
                sta $b9                 ;*******
		ldx zfe
		ldy tff
		jsr $ffd5               ;load
		stx zf3
		sty zf2
		php
		lda #$99		;153
		sta p5
		lda m172
		clc
		adc #3
		sta p5+1
;		lda $ba
;		jsr $ffb4               ;talk
;		lda #$6f		;111
;		sta $b9
;		jsr $ff96               ;tksa

                lda #0                  ;*******
                sta $b7                 ;*******
                lda #$6f                ;*******
                sta $b8                 ;*******
                sta $b9                 ;*******
                jsr $ffc0               ;*******
                ldx #$6f                ;*******
                jsr $ffc6               ;*******
                nop                     ;*******

		ldy #0
lcd2f
		jsr $ffcf		;******$ffa5               ;acptr
		cmp #$0d		;13
		beq lcd41
		and #%01111111
		sta (p5),y
		iny
		cpy #$26		;"&"
		bne lcd2f
		beq lcd4a
lcd41
		lda #$20		;" "
		sta (p5),y
		iny
		cpy #$26		;"&"
		bne lcd41
lcd4a
		jsr $ffcc		;**********$ffab               ;untalk
		jsr $ffe7               ;clall
		plp
		bcc *+5
		jmp (p165)
					;cd56
		sei
		lda #$38		;"8"
		sta $01
		lda #$45		;"E"
		sta p9
		lda m172
		sta p9+1
		ldy #3
		lda z88
		jsr ldd62
		lda z89
		jsr ldd62
		ldy #9
		lda zf3
		jsr ldd62
		lda zf2
		jsr ldd62
		jsr l136
		ldx #$0e		;14
		stx m124
		stx m125
		lda #$48		;"H"
		ldy #1
		sta $fffa
		sty $fffb
		sta $318
		sty $319
		lda #$45		;"E"
		sta $314
		sty $315
		lda #$42		;"B"
		sta $fffe
		sty $ffff
		jsr l130
		lda #$81		;129
		sta mdc0d
		lda #0
		sta $d01a
		lsr $d019
		lda mdc0d
		cli
		jmp (p165)
					;cdbe
lcdbe
		pha			;stackjump attempt
		txa
		pha			;stackjump attempt
		tya
		pha			;stackjump attempt
lcdc3
		lda $01
		pha			;stackjump attempt
		lda #$35		;"5"
		sta $01
		lda #1
		sta $d019
		lda m162
		bne *+5
		jmp (p16b)
					;cdd7
		lda $dc08
		ldx #9
lcddc
		lda z2,x
		sta t10a,x
		lda t100,x
		sta z2,x
		dex
		bpl lcddc
lcde9
		lda #9
		sta $d020
		php
		jsr l15f
		plp
		lda #$35		;"5"
		sta $01
		lda #0
		sta $d020
		lda #$7f		;127
		sta $dc00
		lda $dc01
		cmp #$fd		;253
		beq lcde9
		ldx #9
lce0a
		lda z2,x
		sta t100,x
		lda t10a,x
		sta z2,x
		dex
		bpl lce0a
		lda #$2b		;"+"
		sta p9
		lda m172
		clc
		adc #3
		sta p9+1
		ldx #2
		ldy #0
lce27
		lda tdc09,x
		pha
		lsr
		lsr
		lsr
		lsr
		ora #%00110000
		sta (p9),y
		pla
		iny
		and #%00001111
		ora #%00110000
		sta (p9),y
		iny
		iny
		dex
		bpl lce27
		ldy #$29		;")"
		lda m176
		sta (p9),y
		lda #$2e		;"."
		sta p9
		ldx #4
		ldy #$28		;"("
lce4f
		lda t100,y
		sta (p9),y
		iny
		dex
		bpl lce4f
		lda m175
		tax
		and #%01111111
		bne lce73
		tay
lce61
		lda (p9),y
		cmp t128,y
		beq lce6c
		blt lce73
		bge lce89
lce6c
		iny
		cpy #5
		bne lce61
		beq lce89
lce73
		dec m125
		bpl lce7d
		lda #$10		;16
		sta m28c
lce7d
		lda mdc0d
		pla			;stack parameters?
		sta $01
		pla			;stack parameters?
		tay
		pla			;stack parameters?
		tax
		pla			;stack parameters?
		rti
					;ce89
lce89
		txa
xce8a
		tay
		sei
		ldx #$ff		;255
		txs
		jsr l136
		tya
		bne lcead
lce95
		lda z2
		sec
		adc z3
		cmp z4
		bne lcea7
		lda #0
		sta z3
		sta z2
		jmp (p167)
					;cea7
lcea7
		jsr l12d
		jmp (p167)
					;cead
lcead
		lda z4
		cmp #3
		blt lce95
		lda #$80		;128
		sta $d40f
		sta $d412
lcebb
		lda $d41b
		adc $d41b
		adc $dc04
		sbc $d012
		cmp z4
		bge lcebb
		cmp m177
		beq lcebb
		sta m177
		tay
		sec
		sbc #$0e		;14
		bge lcedc
		lda #0
		.byte $2c		;bit
lcedc
		ldy #$0e		;14
		sty z2
		sta z3
		jmp (p167)
					;cee5
lcee5
		sei
		lda #$37		;"7"
		sta $01
		lda #$81		;129
		sta mdc0d
		lda #$7f		;127
		sta mdd0d
		bit mdc0d
		bit mdd0d
		sta $dc00
		lda #$11		;17
		sta $dc0e
		lda #8
		sta $dc0e+1
		sta mdd0e
		sta mdd0e+1
		lda #0
		sta $d01a
		dec $d019
		sta $dc01+2
		sta m162
		ldx #$0a		;10
lcf1d
		sta $00,x
		inx
		bne lcf1d
		ldx #$18		;24
lcf24
		sta $d400,x
		dex
		bpl lcf24
		stx $dc01+1
		inc $01
		ldx #$31		;"1"
lcf31
		lda tdf50,x
		sta $300,x
		dex
		bpl lcf31
		stx zcc
		lda #$36		;"6"
		sta $01
		rts
					;cf41
		.fill 3119,$00
ldb70
		lda #$29		;")"
		sta p9
		lda zc
		ldy #0
		sta (p9),y
		lda #$80		;128
		sta p9
		ldy #$1e		;30
ldb80
		lda t22,y
		sta (p9),y
		dey
		bpl ldb80
		ldx #$1e		;30
		ldy #$46		;"F"
ldb8c
		lda z42,x
		sta (p9),y
		dey
		dex
		bpl ldb8c
		ldx #$1e		;30
		ldy #$6e		;110
ldb98                                   ;accessed parameter
		lda z62,x
		sta (p9),y
		dey
		dex
		bpl ldb98
		lda z83
		pha
		and #%00110000
		lsr
		lsr
		tax
		ldy #$a0		;160
ldbaa
		lda tde17,x
		sta (p9),y
		inx
		iny
		cpy #$a4		;164
		bne ldbaa
		pla
		and #%00001100
		tax
		lsr
		lsr
		sta m17e
		ldy #$c8		;200
ldbc0
		lda tde27,x
		sta (p9),y
		inx
		iny
		cpy #$cc		;204
		bne ldbc0
		ldy #$f3		;243
		lda z17
		sta m15d
		jsr ldd62
		lda z16
		sta m15e
		jsr ldd62
		inc p9+1
		ldy #$1b		;27
		lda z19
		sta m160
		jsr ldd62
		lda z18
		sta m161
		jsr ldd62
		ldx z1b
		dex
		stx m179
		ldx z1d
		dex
		stx m178
		ldx #3
ldbff                                   ;accessed parameter
		lda z1e,x
		sta t17a,x
		dex
		bpl ldbff
		lda z88
tdc09
		sec
		sbc z13
mdc0d           = *+1			;accessed parameter
		sta zfe
		lda z89
		sbc z12
		sta tff
		lda z84
		bne *+5
		jmp ldcff
					;dc1b
		cmp #$ff		;255
		bne *+5
		jmp ldcd5
					;dc22
		and #%00000011
		beq ldc30
		eor #%00000011
		tax
ldc29
		inc z84
		dec z85
		dex
		bpl ldc29
ldc30
		ldx #$0c		;12
		lda z84
		and #%11000000
		lsr
		lsr
		lsr
		lsr
		lsr
		lsr
		sta zf6
		cmp #0
		beq ldc85
		cmp #2
		beq ldca3
		cmp #3
		beq ldcbb
		lda z84
		clc
		adc #$0c		;12
		sta m173
		and #%00000111
		beq ldc5f
		lda m173
		clc
		adc #4
		sta m173
ldc5f
		lda m173
		clc
		adc #7
		and #%11000000
		lsr
		lsr
		lsr
		lsr
		lsr
		lsr
		cmp zf6
		beq ldcc2
		lda z85
		cmp #$18		;24
		blt ldcd5
		sec
		sbc #4
		sta z85
		lda z84
		clc
		adc #4
		sta z84
		bne ldc30
ldc85
		lda z84
		cmp #$20		;" "
		bge ldccc
		cmp #$10		;16
		blt ldccc
		lda z85
		cmp #$0c		;12
		blt ldcd5
		sec
		sbc #4
		sta z85
		lda z84
		clc
		adc #4
		sta z84
		bne ldc85
ldca3
		lda z84
		cmp #$a0		;160
		bge ldccc
		cmp #$90		;144
		blt ldccc
		clc
		adc #4
		sta z84
		lda z85
		clc
		adc #4
		sta z85
		bne ldca3
ldcbb
		lda #$f8		;248
		sta m173
		bne ldccc
ldcc2
		lda m173
		clc
		adc #8
		sec
		sbc z84
		tax
ldccc
		stx zf5
		lda z85
		sec
		sbc zf5
		bge ldcfb
ldcd5
		lda #$99		;153
		sta p9
		lda m172
		clc
		adc #3
		sta p9+1
		ldy #$17		;23
ldce3
		lda tde37,y
		sta (p9),y
		dey
		bpl ldce3
		lda m172
		clc
		adc #4
		pha			;stackjump attempt
		lda #5
		pha			;stackjump attempt
		lda #5
		sta m124
		rts
					;dcfb
ldcfb
		ldx z84
		bne ldd12
ldcff                                   ;accessed parameter
		lda #$f8		;248
		sta m173
		ldx #$c4		;196
		lda zfe
		cmp #$41		;"A"
		lda tff
mdd0d           = *+1			;accessed parameter
		sbc #$0f		;15
mdd0e                                   ;accessed parameter
		blt ldd12
		ldx #4
ldd12
		ldy m172
		sty p7+1
		stx p5+1
		stx m172
		ldx #$0c		;12
		ldy #0
		sty p5
		sty p7
		lda p5+1
		cmp p7+1
		blt ldd49
		clc
		adc #$0b		;11
		sta p5+1
		lda p7+1
		clc
		adc #$0b		;11
		sta p7+1
		dey
ldd37
		lda (p7),y
		sta (p5),y
		dey
		cpy #$ff		;255
		bne ldd37
		dec p7+1
		dec p5+1
		dex
		bne ldd37
		beq ldd57
ldd49
		lda (p7),y
		sta (p5),y
		iny
		bne ldd49
		inc p7+1
		inc p5+1
		dex
		bne ldd49
ldd57
		lda m172
		clc
		adc #8
		pha			;stackjump attempt
		lda #$77		;119
		pha			;stackjump attempt
		rts
					;dd62
;---------------
ldd62
		jsr ldd6d
		sta (p9),y
		dey
		txa
		sta (p9),y
		dey
		rts
					;dd6d
;---------------
ldd6d
		pha
		lsr
		lsr
		lsr
		lsr
		jsr ldd79
		tax
		pla
		and #%00001111
;---------------
ldd79
		clc
		adc #$30		;48
		cmp #$3a		;":"
		bmi *+4
		adc #6
		rts
					;dd83
;---------------
ldd83
		lda #$f8		;248
		sta p9
		lda m172
		clc
		adc #0
		sta p9+1
		ldx m178
		inx
		stx ze
		ldx m179
		inx
		stx zf
		ldy #0
		ldx #0
ldd9f
		sed
		lda #0
		sta zc
		sta zd
		lda #8
		sta z10
lddaa
		asl ze,x
		lda zc
		adc zc
		sta zc
		lda zd
		adc zd
		sta zd
		dec z10
		bne lddaa
		cld
		lda zd
		beq lddc6
		ora #%00110000
		sta (p9),y
		iny
lddc6
		lda zc
		and #%11110000
		beq lddd5
		lsr
		lsr
		lsr
		lsr
		ora #%00110000
		sta (p9),y
		iny
lddd5
		lda zc
		and #%00001111
		ora #%00110000
		sta (p9),y
		iny
		cpx #0
		bne lddea
		lda #$2f		;"/"
		sta (p9),y
		iny
		inx
		bne ldd9f
lddea
		lda #$20		;" "
		sta (p9),y
		iny
		cpy #8
		blt lddea
		ldx #0
		ldy #3
lddf7
		lda #8
		sta z10
		lda t17a,y
lddfe
		lsr
		pha
		lda #0
		bcc *+4
		lda #1
		sta p9
		pla
		cpx m178
		beq lde16_rts
		inx
		dec z10
		bne lddfe
		dey
		bpl lddf7
lde16_rts
		rts
					;de17
tde17
		.byte "<?> 65818580BOTH"
tde27
		.byte "<?> PAL NTSCBOTH"
tde37
		.byte "NOT ENOUGH MEMORY ERROR!"
